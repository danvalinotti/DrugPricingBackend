package com.galaxe.drugpriceapi.web.nap.ui;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class Output {

        private String zip;

        private String latitude;

        private String longitude;


}
