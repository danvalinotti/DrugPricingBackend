package com.galaxe.drugpriceapi.web.nap.postgresMigration.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;

@Getter
@Setter
public class StringSender {
    String value ;

    String key;


}
