package com.galaxe.drugpriceapi.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BrandList {


    private String gpi10;

    private String name;

    private String drugType;


}