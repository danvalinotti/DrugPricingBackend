package com.galaxe.drugpriceapi.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Drug2 {

    private String gpi10;

    private String gpi;

    private String brandName;

    private String ndc;

    private String productName;

    private String drugType;

}
