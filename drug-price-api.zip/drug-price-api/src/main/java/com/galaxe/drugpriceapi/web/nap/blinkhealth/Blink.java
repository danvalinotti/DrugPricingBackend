package com.galaxe.drugpriceapi.web.nap.blinkhealth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Blink {

    Results results;
    Price price;
}
