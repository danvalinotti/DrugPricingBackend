package com.galaxe.drugpriceapi.web.nap.blinkhealth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BlinkHealth {

    private BlinkResult result;
}
