package com.galaxe.drugpriceapi.web.nap.medimpact;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Quantities {

    private LocatedDrugQty[] locatedDrugQty;
}
