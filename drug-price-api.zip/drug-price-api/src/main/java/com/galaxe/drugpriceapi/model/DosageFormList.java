package com.galaxe.drugpriceapi.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DosageFormList {


    private String unitName;

    private String gpiCode;

    private String name;
}
