package com.galaxe.drugpriceapi.web.nap.ui;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ZipcodeConverter {
    private List<Output> output;

    private String status;
}


