package com.galaxe.drugpriceapi.web.nap.medimpact;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocatedDrugStrength {

    private String gsn;

    private String strength;

    private String isSelected;

    private String ranking;

}
