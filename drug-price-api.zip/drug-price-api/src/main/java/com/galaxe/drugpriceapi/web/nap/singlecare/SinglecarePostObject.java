package com.galaxe.drugpriceapi.web.nap.singlecare;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SinglecarePostObject {

    private PValue Value;
}
