package com.galaxe.drugpriceapi.web.nap.medimpact;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LocatedDrugName {

    private String brandGenericIndicator;

    private String drugName;

    private String isSelected;
}
