package com.galaxe.drugpriceapi.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GpsCoords {
    private String lng;

    private String lat;
}