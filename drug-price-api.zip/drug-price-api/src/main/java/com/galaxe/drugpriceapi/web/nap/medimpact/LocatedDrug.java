package com.galaxe.drugpriceapi.web.nap.medimpact;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocatedDrug {

    private Pharmacy pharmacy;

    private Pricing pricing;

}
