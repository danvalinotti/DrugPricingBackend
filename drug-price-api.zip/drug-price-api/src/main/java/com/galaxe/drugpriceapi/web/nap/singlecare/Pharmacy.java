package com.galaxe.drugpriceapi.web.nap.singlecare;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Pharmacy {

    private Address Address;

    private String Name;
}
