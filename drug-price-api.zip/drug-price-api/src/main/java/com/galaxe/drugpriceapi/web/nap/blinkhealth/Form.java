package com.galaxe.drugpriceapi.web.nap.blinkhealth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Form {
    public String GSN;
    public String Form;
    public Boolean IsSelected;

}
