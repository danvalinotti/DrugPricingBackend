package com.galaxe.drugpriceapi.web.nap.medimpact;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocatedDrugForm {

    private String gsn;

    private String form;

    private String isSelected;

    private String ranking;

}
