package com.galaxe.drugpriceapi.web.nap.wellRx;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Strengths {

    private String GSN;

    private String Strength;

}
