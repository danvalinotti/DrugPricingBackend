package com.galaxe.drugpriceapi.web.nap.medimpact;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Forms {

    private LocatedDrugForm[] locatedDrugForm;

}
