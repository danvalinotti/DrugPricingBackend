package com.galaxe.drugpriceapi.model;


import lombok.Getter;
import lombok.Setter;
import java.util.*;

@Getter
@Setter
public class InsideRx {

    private List<Prices> prices;
}


